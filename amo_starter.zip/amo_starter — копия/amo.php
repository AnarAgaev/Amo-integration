<?php
// header('Content-type: text/plain; charset=utf-8');
// ini_set('error_reporting', E_ALL);
// ini_set('display_errors', 1);
// ini_set('display_startup_errors', 1);
include "vendor/autoload.php";

use AmoCRM\{AmoAPI, AmoLead, AmoContact, AmoNote, AmoIncomingLeadForm, AmoAPIException};

$file_response = 'log.log';
// if (!empty($_GET)) {
// 	$fw = fopen($file_response, "a");
// 	fwrite($fw, "GET " . var_export($_GET, true) . "\n");
// 	fclose($fw);
// }
// if (!empty($_POST)) {
// 	$fw = fopen($file_response, "a");
// 	fwrite($fw, "POST " . var_export($_POST, true) . "\n");
// 	fclose($fw);
// }

try {
	
	// Авторизация
	$subdomain = 'houseinhouse';
	AmoAPI::oAuth2($subdomain);
	// AmoAPI::$debug = true;
	// AmoAPI::$debugLogFile = __DIR__.'/log.log';
	// Создаем новую заявку в неразобранном при добавлении из веб-формы
	$incomingLead = new AmoIncomingLeadForm();

	// Добавляем параметры сделки
	$lead = new AmoLead([
		'name' => $subject
	]);
	$lead->addTags([ 'домик-в-доме.рф' ]);
	// $lead->setCustomFields([ 
	// 	603239 => [[

	// 		'value'  => 1323479
	// 	]]
	//  ]);

	if($_COOKIE['utm_source']){
		$lead->setCustomFields([ 31943 => $_COOKIE['utm_source'] ]);
		$lead->setCustomFields([ 31937 => $_COOKIE['utm_content'] ]);
		$lead->setCustomFields([ 31939 => $_COOKIE['utm_medium'] ]);
		$lead->setCustomFields([ 31941 => $_COOKIE['utm_campaign'] ]);
		$lead->setCustomFields([ 31945 => $_COOKIE['utm_term'] ]);
	}
	$incomingLead->addIncomingLead($lead);

	$contact = new AmoContact([
		'name' => "Уточнить имя!"
	]);

	$contact->setCustomFields([
		31929 => [[
			'value' => $phone,
			'enum'  => 'WORK'
		]],
	]);
	if ($email != '') {
		$contact->setCustomFields([
			31931 => [[
				'value' => $email,
				'enum'  => 'WORK'
			]]
		]);
	}

	$incomingLead->addIncomingContact($contact);
	// Устанавливаем обязательные параметры 
	$incomingLead->setIncomingLeadInfo([
		'form_id'   => 860245,
		'form_page' => 'https://домик-в-доме.рф/',
		'form_name' => 'домик-в-доме.рф',
		'form_send_at' => time(),
	]);
	// Сохраняем заявку
	$data = $incomingLead->save();


	$incomingLead2 = new AmoIncomingLeadForm();
	$incomingLead2->fillByUid($data[0]);
	$lead = $incomingLead2->getParams();

	//  echo "<pre>";
    // print_r($lead);
	//  echo "</pre>";
	$leadId = $lead['incoming_entities']['leads'][0]['id'];
	// echo $leadId;
	if($message2 !=''){
		// Создание нового события типа "обычное примечание", привязанного к сделке
		$note = new AmoNote([
			'element_id'   => $leadId,
			'note_type'    => AmoNote::COMMON_NOTETYPE,
			'element_type' => AmoNOTE::LEAD_TYPE,
			'text'         => $message2
		]);

	  // Сохранение события и получение его ID
		$noteId = $note->save();
	}
	// Принимаем заявки из неразобранного
	AmoAPI::acceptIncomingLeads([
		'accept' => [
			$data[0],
		],
		'user_id'   => 1996752,
		'status_id' => 42731941
	]);
	// print_r(AmoAPI::getAccount());
} catch (AmoAPIException $e) {
	printf('Ошибка (%d): %s' . PHP_EOL, $e->getCode(), $e->getMessage());
}

