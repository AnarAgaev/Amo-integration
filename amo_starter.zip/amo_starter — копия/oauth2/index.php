<?php
header('Content-type: text/plain; charset=utf-8');
ini_set('error_reporting', E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
include "../vendor/autoload.php";
use AmoCRM\{AmoAPI, AmoAPIException};
use AmoCRM\TokenStorage\{FileStorage, TokenStorageException};

try {
    // Параметры авторизации по протоколу oAuth 2.0
    $clientId     = 'd78ff3d1-b2ab-44ed-b164-488e426a1075';
    $clientSecret = 'mnIgHGr8xP99usTKDAVMwf46vFco5IYxC9zGCOe9MYYyQIvq4YGmHRdempDBvdkF';
    $authCode     = 'def50200f15f2f5dc4fc6ada58a5aa40f776200cfb60e73f6e4a80f63f54f8bbda0269adec894c95e140f185f02dfee2fa8f6d0227ebdddb03cd687037e91470fd1b39b17d4aa763a031d3973beaa04e030cfc2d7ad13c4c4d2d2590fe6093b9191ecad6cc04445c7bcb9284d75ed4bb380e8013c279eff6f541deb3aa9ca31da8cda31544ad31d27ab10228faf04f8ab4b3567e60a563da8e15b21a564dc1fd4f0e8121914f7c578c4455152454dacc0fb7014c8c9076350eb5a27b21b83b955cd6c148c352897667d2dda2cd80d17bfaa52aec99b536f3eb931a2a40881d7b112b894cf7691edaef65c2bc859768a480690737e4b51e973174826d633dc5787b70d8277bf9de776c2c7081dfacbdb9e8ccd46157ea84f8b5319841a387c8bc6ae6515e24b3d4784d355bb277d8fc38ec83013fd487274e41cb33421e8ed1dcd7a454b3f032031f113955e3d06af729bef4f7c82384b7123be8450682e5f6e5bd319088d49336038117c3dcde657d63834907218aa0effbb8a48762bff96d2867e8a2e4d11b0cf22953d92322f5dbd034c4ff0b8b8bdc5377c71925b86e8d97613aa0e7930ef215083761f4e27822a4918bc8e741bd1c072172dd13bdcbdb4047ae50b4218aaa172044';
    $redirectUri  = 'https://i-love-hair.ru/oauth2/';
    $subdomain    = 'iloveyouhair';

    $domain = AmoAPI::getAmoDomain($subdomain);
    $isFirstAuth = !(new FileStorage())->hasTokens($domain);

    if ($isFirstAuth) {
        // Первичная авторизация
        AmoAPI::oAuth2($subdomain, $clientId, $clientSecret, $redirectUri, $authCode);
    } else {
        // Последующие авторизации
        AmoAPI::oAuth2($subdomain);
    }

    // Получение информации об аккаунте вместе с пользователями и группами
    print_r(AmoAPI::getAccount($with = 'users,groups'));
    print_r(AmoAPI::getAccount($with = 'custom_fields'));

} catch (AmoAPIException $e) {
    printf('Ошибка авторизации (%d): %s' . PHP_EOL, $e->getCode(), $e->getMessage());
} catch (TokenStorageException $e) {
    printf('Ошибка обработки токенов (%d): %s' . PHP_EOL, $e->getCode(), $e->getMessage());
}